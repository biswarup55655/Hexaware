from unittest.mock import Mock, MagicMock

import pytest

from entity.Lease import Lease
from main.main import MainModule
from entity.Vehicle import Vehicles
from exception.custom_exception import CarNotFoundException, CustomerNotFoundException, LeaseNotFoundException


@pytest.fixture
def main_module():
    return MainModule()


def test_add_car(main_module):
    mock_cursor = Mock()
    mock_connection = Mock()
    mock_connection.cursor.return_value = mock_cursor
    main_module.car_lease.connection = mock_connection
    vehicle = Vehicles("Toyota", "Corolla", 2022, 175.00, "available",
                       5, 1.8)
    main_module.car_lease.addCar(vehicle)
    mock_cursor.execute.assert_called_once()
    mock_connection.commit.assert_not_called()

    car = main_module.car_lease.findCarById(1)
    assert car is not None


def test_create_lease(main_module):
    mock_cursor = Mock()
    mock_connection = Mock()
    mock_connection.cursor.return_value = mock_cursor
    main_module.car_lease.connection = mock_connection
    lease = Lease(1, 1, "2024-02-05", "2024-02-06", "DailyLease")
    main_module.car_lease.createLease(lease)
    mock_cursor.execute.assert_called_once()
    mock_connection.commit.assert_not_called()

    lease_found = main_module.car_lease.findLeaseById(1)
    assert lease_found is not None


def test_retrieve_lease(main_module):
    lease = main_module.car_lease.findLeaseById(1)
    assert lease is not None


def test_car_not_found_exception(main_module):
    with pytest.raises(CarNotFoundException):
        main_module.car_lease.findCarById(1000)


def test_customer_not_found_exception(main_module):
    with pytest.raises(CustomerNotFoundException):
        main_module.car_lease.findCustomerById(1000)


def test_lease_not_found_exception(main_module):
    with pytest.raises(LeaseNotFoundException):
        main_module.car_lease.findLeaseById(1000)
