class Vehicles:
    def __init__(self, make, model, year, daily_rate, status, passenger_capacity, engine_capacity):
        self.__make = make
        self.__model = model
        self.__year = year
        self.__dailyRate = daily_rate
        self.__status = status
        self.__passengerCapacity = passenger_capacity
        self.__engineCapacity = engine_capacity

    @property
    def make(self):
        return self.__make

    @make.setter
    def make(self, val):
        self.__make = val

    @property
    def model(self):
        return self.__model

    @model.setter
    def model(self, new_model):
        self.__model = new_model

    @property
    def year(self):
        return self.__year

    @year.setter
    def year(self, new_year):
        self.__year = new_year

    @property
    def dailyRate(self):
        return self.__dailyRate

    @dailyRate.setter
    def dailyRate(self, new_rate):
        self.__dailyRate = new_rate

    @property
    def status(self):
        return self.__status

    @status.setter
    def status(self, new_status):
        self.__status = new_status

    @property
    def passengerCapacity(self):
        return self.__passengerCapacity

    @passengerCapacity.setter
    def passengerCapacity(self, passenger_capacity):
        self.__passengerCapacity = passenger_capacity

    @property
    def engineCapacity(self):
        return self.__engineCapacity

    @engineCapacity.setter
    def engineCapacity(self, engine_capacity):
        self.__engineCapacity = engine_capacity
