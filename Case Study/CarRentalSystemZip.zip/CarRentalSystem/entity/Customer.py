class Customers:
    def __init__(self, first_name, last_name, email, phone_number):
        self.__firstName = first_name
        self.__lastName = last_name
        self.__email = email
        self.__phoneNumber = phone_number

    @property
    def firstName(self):
        return self.__firstName

    @firstName.setter
    def firstName(self, first_name):
        self.__firstName = first_name

    @property
    def lastName(self):
        return self.__lastName

    @lastName.setter
    def lastName(self, last_name):
        self.__lastName = last_name

    @property
    def email(self):
        return self.__email

    @email.setter
    def email(self, set_email):
        self.__email = set_email

    @property
    def phoneNumber(self):
        return self.__phoneNumber

    @phoneNumber.setter
    def phoneNumber(self, phome_number):
        self.__phoneNumber = phome_number
