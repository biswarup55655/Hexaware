class Lease:
    def __init__(self, vehicle_id, customer_id, start_date, end_date, vehicle_type):
        self.__vehicleID = vehicle_id
        self.__customerID = customer_id
        self.__startDate = start_date
        self.__endDate = end_date
        self.__type = vehicle_type

    @property
    def vehicleID(self):
        return self.__vehicleID

    @vehicleID.setter
    def vehicleID(self, vehicle_id):
        self.__vehicleID = vehicle_id

    @property
    def customerID(self):
        return self.__customerID

    @customerID.setter
    def customerID(self, customer_id):
        self.__customerID = customer_id

    @property
    def startDate(self):
        return self.__startDate

    @startDate.setter
    def startDate(self, start_date):
        self.__startDate = start_date

    @property
    def endDate(self):
        return self.__endDate

    @endDate.setter
    def endDate(self, end_date):
        self.__endDate = end_date

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, new_type):
        self.__type = new_type
