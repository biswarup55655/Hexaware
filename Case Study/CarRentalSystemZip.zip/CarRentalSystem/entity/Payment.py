class Payments:
    def __init__(self, payment_id, lease_id, payment_date, amount):
        self.__paymentID = payment_id
        self.__leaseID = lease_id
        self.__paymentDate = payment_date
        self.__amount = amount

    @property
    def paymentID(self):
        return self.__paymentID

    @property
    def leaseID(self):
        return self.__leaseID

    @leaseID.setter
    def leaseID(self, lease_id):
        self.__leaseID = lease_id

    @property
    def paymentDate(self):
        return self.__paymentDate

    @paymentDate.setter
    def paymentDate(self, payment_date):
        self.__paymentDate = payment_date

    @property
    def amount(self):
        return self.__amount

    @amount.setter
    def amount(self,new_amount):
        self.__amount = new_amount
