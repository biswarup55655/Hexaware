class CarNotFoundException(Exception):
    pass


class LeaseNotFoundException(Exception):
    pass


class CustomerNotFoundException(Exception):
    pass
