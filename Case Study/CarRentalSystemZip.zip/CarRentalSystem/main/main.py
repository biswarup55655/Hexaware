from colorama.ansi import clear_screen

from dao.ICarLeaseRepositoryImpl import CarLeaseRepositoryImpl
from entity.Customer import Customers
from entity.Lease import Lease
from entity.Vehicle import Vehicles
import mysql.connector


class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'


class MainModule:
    def __init__(self):
        self.connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='rupen',
            database='carrentalsystem'
        )
        self.car_lease = CarLeaseRepositoryImpl(self.connection)
        self.logged_in_user = None

    def run(self):
        while True:
            choice = input("Choose an option:\n1. Login\n2. Register\n3. Exit\nEnter choice: ")
            if choice == '1':
                self.login()
            elif choice == '2':
                self.register_user()
            elif choice == '3':
                break
            else:
                print("Invalid choice. Please enter '1' for login or '2' for registration or '3' to Exit")

    def login(self):
        user_role = self.authenticate_user()
        if user_role == 'admin':
            self.run_admin()
        elif user_role == 'user':
            self.run_client()
        else:
            print("Invalid role. Exiting...")

    def authenticate_user(self):
        while True:
            role = input("Enter role (admin/user): ").lower()
            if role == 'admin' or role == 'user':
                username = input("Enter username: ")
                password = input("Enter password: ")
                if role == 'admin':
                    admin = self.login_admin(username, password)
                    if admin:
                        print("Admin logged in successfully.")
                        self.logged_in_user = 'admin'
                        return 'admin'
                    else:
                        print("Invalid credentials. Try again.")
                elif role == 'user':
                    user = self.login_user(username, password)
                    if user:
                        print("User logged in successfully.")
                        self.logged_in_user = 'user'
                        return 'user'
                    else:
                        print("Invalid credentials. Try again.")
            else:
                print("Invalid role. Try again.")

    @staticmethod
    def display_menu():
        clear_screen()
        print(Colors.HEADER + "***** Welcome To Car Rental System *****" + Colors.ENDC)

    @staticmethod
    def display_admin_menu():
        clear_screen()
        print(Colors.BLUE + "***** Admin Menu *****" + Colors.ENDC)
        print("1. Add Car")
        print("2. Remove Car")
        print("3. List Rented Cars")
        print("4. Update Car Availability")
        print("5. Add Customer")
        print("6. Remove Customer")
        print("7. Update customer")
        print("8. List all customer")
        print("9. Create Lease")
        print("10. Record Payment")
        print("11. Calculate total revenue")
        print("12. Show active Lease")
        print("13. List Lease History")
        print("14. Register New Admin")
        print("0. Logout")

    @staticmethod
    def display_client_menu():
        clear_screen()
        print(Colors.GREEN + "***** Client Menu *****" + Colors.ENDC)
        print("1. List Available Cars")
        print("2. Find Car by ID")
        print("3. Calculate lease cost")
        print("4. Find Customer by ID")
        print("5. Get payment history for Customer")
        print("6. Find Lease by ID")
        print("0. Logout")

    def username_available(self, username):
        cursor = self.connection.cursor()
        query = "SELECT * FROM Admin WHERE username = %s"
        cursor.execute(query, (username,))
        admin = cursor.fetchone()
        cursor.close()
        return admin is None

    def register_admin(self):
        print(Colors.BLUE + "Register as ADMIN." + Colors.ENDC)
        if self.logged_in_user == 'admin':
            username = input("Enter username: ")
            password = input("Enter password: ")
            if self.username_available(username):
                cursor = self.connection.cursor()
                query = "INSERT INTO Admin (username, password) VALUES (%s, %s)"
                cursor.execute(query, (username, password))
                self.connection.commit()
                cursor.close()
                print("Admin registered successfully.")
            else:
                print("Username already exists. Please choose another username.")
        else:
            print("You must be logged in as an admin to register a new admin.")

    def register_user(self):
        print(Colors.BLUE + "Register as USER." + Colors.ENDC)
        username = input("Enter username: ")
        password = input("Enter password: ")
        if self.username_available(username):
            cursor = self.connection.cursor()
            query = "INSERT INTO User (username, password) VALUES (%s, %s)"
            cursor.execute(query, (username, password))
            self.connection.commit()
            cursor.close()
            print("User registered successfully.")
        else:
            print("Username already exists. Please choose another username.")

    def login_admin(self, username, password):
        cursor = self.connection.cursor()
        query = "SELECT * FROM Admin WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        admin = cursor.fetchone()
        cursor.close()
        return admin

    def login_user(self, username, password):
        cursor = self.connection.cursor()
        query = "SELECT * FROM User WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        user = cursor.fetchone()
        cursor.close()
        return user

    def run_admin(self):
        while True:
            self.display_admin_menu()
            choice = input("Enter your choice: ")
            if choice == "0":
                print("Exiting admin menu...")
                break
            elif choice == "1":
                self.add_car()
            elif choice == "2":
                self.remove_car()
            elif choice == "3":
                self.list_rented_cars()
            elif choice == "4":
                self.update_car_status()
            elif choice == "5":
                self.add_customer()
            elif choice == "6":
                self.remove_customer()
            elif choice == "7":
                self.update_customer()
            elif choice == "8":
                self.list_customers()
            elif choice == "9":
                self.create_lease()
            elif choice == "10":
                self.record_payment()
            elif choice == "11":
                self.calculate_total_revenue()
            elif choice == "12":
                self.list_active_leases()
            elif choice == "13":
                self.list_lease_history()
            elif choice == "14":
                self.register_admin()
            else:
                print("Invalid choice")

    def run_client(self):
        while True:
            self.display_client_menu()
            choice = input("Enter your choice: ")
            if choice == "0":
                print("Exiting User menu...")
                break
            elif choice == "1":
                self.list_available_cars()
            elif choice == "2":
                self.find_car_by_id()
            elif choice == "3":
                self.calculate_lease_cost()
            elif choice == "4":
                self.find_customer_by_id()
            elif choice == "5":
                self.get_payment_history_for_customer()
            elif choice == "6":
                self.findLeaseById()
            else:
                print("Invalid choice")

    def add_car(self):
        make = input("Enter make: ")
        model = input("Enter model: ")
        year = int(input("Enter year: "))
        daily_rate = float(input("Enter daily rate: "))
        status = input("Enter status (available / not available): ")
        passenger_capacity = int(input("Enter passenger capacity: "))
        engine_capacity = float(input("Enter engine capacity: "))
        vehicle = Vehicles(make, model, year, daily_rate, status, passenger_capacity, engine_capacity)
        self.car_lease.addCar(vehicle)
        print("Car added successfully.")

    def update_car_status(self):
        car_id = int(input("Enter the vehicle id: "))
        if self.car_lease.findCarById(car_id):
            status = input("Enter current status:")
            self.car_lease.updateCarAvailability(car_id, status)
            print("Car Status updated successfully!")
        else:
            print("Car not found")

    def remove_car(self):
        vehicle_id = int(input("Enter vehicle ID to remove: "))
        self.car_lease.removeCar(vehicle_id)
        print("Car removed successfully.")

    def list_available_cars(self):
        available_cars = self.car_lease.listAvailableCars()
        print("Available Cars:")
        for car in available_cars:
            print(f"Vehicle ID: {car[0]} || Make: {car[1]} || model: {car[2]} || year: {car[3]} || "
                  f"daily_rate: {car[4]} || status: {car[5]} || passenger_capacity: {car[6]} ||"
                  f"passenger_capacity: {car[7]}")

    def list_rented_cars(self):
        rented_cars = self.car_lease.listRentedCars()
        print("Rented Cars:")
        for car in rented_cars:
            print(car)

    def find_car_by_id(self):
        car_id = int(input("Enter Car ID: "))
        car = self.car_lease.findCarById(car_id)
        if car:
            print("Car found:",
                  "\ncar ID:", car[0],
                  "\nmake:", car[1],
                  "\nmodel:", car[2],
                  "\nyear:", car[3],
                  "\nPrice:", car[4],
                  "\nStatus:", car[5],
                  "\nSeat capacity:", car[6],
                  "\nEngine capacity:", car[7])
        else:
            print("Car not found")

    def add_customer(self):
        first_name = input("Enter first name: ")
        last_name = input("Enter last name: ")
        email = input("Enter email: ")
        phone_number = input("Enter phone number: ")
        customer = Customers(first_name, last_name, email, phone_number)
        self.car_lease.addCustomer(customer)
        print("Customer added successfully.")

    def remove_customer(self):
        customer_id = int(input("Enter customer ID to remove: "))
        try:
            if self.car_lease.findCustomerById(customer_id):
                self.car_lease.removeCustomer(customer_id)
                print("Customer removed successfully.")
            else:
                print("Customer not found.")
        except Exception as e:
            print("An error occurred:", e)

    def list_customers(self):
        customers = self.car_lease.listCustomers()
        print("Customers:")
        for customer in customers:
            print("\nCutomer ID:", customer[0],
                  "\nfirst_name:", customer[1],
                  "\nlast_name:", customer[2],
                  "\nemail:", customer[3],
                  "\nphone_number:", customer[4])

    def find_customer_by_id(self):
        customer_id = int(input("Enter Customer ID: "))
        customer = self.car_lease.findCustomerById(customer_id)
        if customer:
            print("Customer found:",
                  "\nCustomer ID:", customer[0],
                  "\nFirst Name:", customer[1],
                  "\nLast Name:", customer[2],
                  "\nEmail:", customer[3],
                  "\nPhone Number:", customer[4])
        else:
            print("Customer not found")

    def create_lease(self):
        available_cars = self.car_lease.listAvailableCars()
        print("Available Cars:")
        for car in available_cars:
            print(car)
        vehicle_id = int(input("Enter Vehicle ID: "))
        customer_id = int(input("Enter Customer ID: "))
        start_date = input("Enter start date: ")
        end_date = input("Enter last date: ")
        v_type = input("Enter vehicle type(DailyLease/MonthlyLease): ")
        new_lease = Lease(vehicle_id, customer_id, start_date, end_date, v_type)
        self.car_lease.createLease(new_lease)
        print("Lease created successfully.")

    def list_active_leases(self):
        active_leases = self.car_lease.listActiveLeases()
        print("Active Leases:")
        for lease in active_leases:
            print("\nLease ID:", lease[0],
                  "\nVehicle ID:", lease[1],
                  "\nCustomer ID:", lease[2],
                  "\nStart Date:", lease[3],
                  "\nEnd Date:", lease[4],
                  "\nType:", lease[5])

    def list_lease_history(self):
        lease_history = self.car_lease.listLeaseHistory()
        print("Lease History:")
        for lease in lease_history:
            print(f"Lease ID: {lease[0]}, Vehicle ID: {lease[1]}, Customer ID: {lease[2]}, "
                  f"Start Date: {lease[3]}, End Date: {lease[4]}, Type: {lease[5]}")

    def record_payment(self):
        lease_id = int(input("Enter Lease ID to record payment: "))
        payment_date = input("Enter date of payment: ")
        amount = float(input("Enter payment amount: "))
        self.car_lease.recordPayment(lease_id, payment_date, amount)
        print("Payment recorded successfully.")

    def calculate_lease_cost(self):
        lease_type = input("Enter lease type (daily/monthly): ")
        duration = int(input("Enter lease duration: "))
        daily_rate = float(input("Enter daily rate: "))
        total_cost = self.car_lease.calculateLeaseCost(lease_type, duration, daily_rate)
        print("Total lease cost:", total_cost)

    def get_payment_history_for_customer(self):
        customer_id = int(input("Enter Customer ID: "))
        payment_history = self.car_lease.getPaymentHistoryForCustomer(customer_id)
        print("Payment History:")
        for payment in payment_history:
            print(f"Lease ID: {payment[0]}, Payment Date: {payment[1]}, Amount: {payment[2]}")

    def calculate_total_revenue(self):
        total_revenue = self.car_lease.calculateTotalRevenue()
        print("Total Revenue:", total_revenue)

    def update_customer(self):
        customer_id = int(input("Enter Customer ID to update: "))
        first_name = input("Enter new first name: ")
        last_name = input("Enter new last name: ")
        email = input("Enter new email: ")
        phone_number = input("Enter new phone number: ")
        new_customer = Customers(first_name, last_name, email, phone_number)
        self.car_lease.updateCustomer(customer_id, new_customer)
        print("Customer information updated successfully.")

    def findLeaseById(self):
        lease_id = int(input("Enter Lease ID: "))
        lease = self.car_lease.findLeaseById(lease_id)
        if lease:
            print("Lease found:",
                  "\nLease ID:", lease[0],
                  "\nVehicle ID:", lease[1],
                  "\nCustomer ID:", lease[2],
                  "\nStart Date:", lease[3],
                  "\nEnd Date:", lease[4],
                  "\nType:", lease[5])
        else:
            print("Lease not found")


if __name__ == "__main__":
    main_module = MainModule()
    main_module.run()
