import mysql.connector
from util.DBPropertyUtil import DBPropertyUtil


class DBConnUtil:
    @staticmethod
    def get_connection(property_file_name):
        connection_string = DBPropertyUtil.get_connection_string(property_file_name)
        return mysql.connector.connect(connection_string)
