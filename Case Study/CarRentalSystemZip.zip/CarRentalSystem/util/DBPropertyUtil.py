from configparser import ConfigParser


class DBPropertyUtil:
    @staticmethod
    def get_connection_string(property_file_name):
        config = ConfigParser()
        config.read(property_file_name)
        user = config.get('database', 'user')
        host = config.get('database', 'host')
        port = config.get('database', 'port')
        database = config.get('database', 'database')
        password = config.get('database', 'password')
        return f"mysql://{user}:{password}@{host}:{port}/{database}"
