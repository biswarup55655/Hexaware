from typing import List
from dao.ICarLeaseRepository import ICarLeaseRepository
from entity import Vehicle, Customer, Lease, Payment
from exception.custom_exception import CarNotFoundException, CustomerNotFoundException, LeaseNotFoundException


class CarLeaseRepositoryImpl(ICarLeaseRepository):
    def __init__(self, connection):
        self.connection = connection

    def addCar(self, vehicle: Vehicle):
        cursor = self.connection.cursor()
        query = ("INSERT INTO Vehicle (make, model, year, dailyRate, status, passengerCapacity, engineCapacity) "
                 "VALUES (%s, %s, %s, %s, %s, %s, %s)")
        data = (vehicle.make, vehicle.model, vehicle.year, vehicle.dailyRate, vehicle.status, vehicle.passengerCapacity,
                vehicle.engineCapacity)
        cursor.execute(query, data)
        if not self.connection.autocommit:
            self.connection.commit()
        cursor.close()

    def removeCar(self, vehicle_id: int):
        cursor = self.connection.cursor()
        query = "DELETE FROM Vehicle WHERE vehicleID = %s"
        cursor.execute(query, (vehicle_id,))
        self.connection.commit()
        cursor.close()

    def updateCarAvailability(self, vehicle_id: int, new_status: str) -> None:
        cursor = self.connection.cursor()
        query = "UPDATE Vehicle SET status = %s WHERE vehicleID = %s"
        cursor.execute(query, (new_status, vehicle_id))
        self.connection.commit()
        cursor.close()

    def listAvailableCars(self) -> List[Vehicle]:
        cursor = self.connection.cursor()
        query = "SELECT * FROM Vehicle WHERE status = 'available'"
        cursor.execute(query)
        vehicles = cursor.fetchall()
        cursor.close()
        return vehicles

    def listRentedCars(self) -> List[Vehicle]:
        cursor = self.connection.cursor()
        query = "SELECT * FROM Vehicle WHERE status = 'not available'"
        cursor.execute(query)
        rented_cars = cursor.fetchall()
        cursor.close()
        return rented_cars

    def findCarById(self, vehicle_id: int) -> Vehicle:
        cursor = self.connection.cursor()
        query = "SELECT * FROM Vehicle WHERE vehicleID = %s"
        cursor.execute(query, (vehicle_id,))
        vehicle = cursor.fetchone()
        cursor.close()
        if vehicle:
            return vehicle
        else:
            raise CarNotFoundException("Car not found with ID: {}".format(vehicle_id))

    def updateCustomer(self, customer_id: int, new_customer: Customer) -> None:
        cursor = self.connection.cursor()
        query = ("UPDATE Customer SET firstName = %s, lastName = %s, email = %s, phoneNumber = %s "
                 "WHERE customerID = %s")
        data = (new_customer.firstName, new_customer.lastName, new_customer.email, new_customer.phoneNumber,
                customer_id)
        cursor.execute(query, data)
        self.connection.commit()
        cursor.close()

    def addCustomer(self, customer: Customer) -> None:
        cursor = self.connection.cursor()
        query = ("INSERT INTO Customer (firstName, lastName, email, phoneNumber) "
                 "VALUES (%s, %s, %s, %s)")
        data = (customer.firstName, customer.lastName, customer.email, customer.phoneNumber)
        cursor.execute(query, data)
        self.connection.commit()
        cursor.close()

    def removeCustomer(self, customer_id: int) -> None:
        cursor = self.connection.cursor()
        try:
            lease_query = "DELETE FROM Lease WHERE customerID = %s"
            cursor.execute(lease_query, (customer_id,))
            customer_query = "DELETE FROM Customer WHERE customerID = %s"
            cursor.execute(customer_query, (customer_id,))
            self.connection.commit()
        except Exception as e:
            print(f"Error occurred: {str(e)}")
            self.connection.rollback()
        finally:
            cursor.close()

    def listCustomers(self) -> List[Customer]:
        cursor = self.connection.cursor()
        query = "SELECT * FROM Customer"
        cursor.execute(query)
        customers = cursor.fetchall()
        cursor.close()
        return customers

    def findCustomerById(self, customer_id: int) -> Customer:
        cursor = self.connection.cursor()
        query = "SELECT * FROM Customer WHERE customerID = %s"
        cursor.execute(query, (customer_id,))
        customer_data = cursor.fetchone()
        cursor.close()
        if customer_data:
            return customer_data
        else:
            raise CustomerNotFoundException("Customer not found with ID: {}".format(customer_id))

    def createLease(self, lease: Lease):
        cursor = self.connection.cursor()
        query = ("INSERT INTO Lease (vehicleID, customerID, startDate, endDate, type) "
                 "VALUES (%s, %s, %s, %s, %s)")
        data = (lease.vehicleID, lease.customerID, lease.startDate, lease.endDate, lease.type)

        try:
            cursor.execute(query, data)
            if not self.connection.autocommit:
                self.connection.commit()
            cursor.close()
        except Exception as e:
            print(f"Error occurred: {str(e)}")
            if not self.connection.autocommit:
                self.connection.rollback()
            cursor.close()

    def listActiveLeases(self) -> List[Lease]:
        cursor = self.connection.cursor()
        query = "SELECT * FROM Lease WHERE CURDATE() >= startDate AND CURDATE() <= endDate"
        cursor.execute(query)
        active_leases = cursor.fetchall()
        cursor.close()
        return active_leases

    def listLeaseHistory(self) -> List[Lease]:
        cursor = self.connection.cursor()
        query = "SELECT * FROM Lease"
        cursor.execute(query)
        lease_history = cursor.fetchall()
        cursor.close()
        return lease_history

    def recordPayment(self, lease: int, date: str, amount: float) -> None:
        cursor = self.connection.cursor()
        query = ("INSERT INTO Payment (leaseID, paymentDate, amount) "
                 "VALUES (%s, %s, %s)")
        data = (lease, date, amount)
        cursor.execute(query, data)
        self.connection.commit()
        cursor.close()

    @staticmethod
    def calculateLeaseCost(lease_type: str, duration: int, daily_rate: float) -> float:
        if lease_type == 'daily':
            return duration * daily_rate
        elif lease_type == 'monthly':
            return duration * 30 * daily_rate

    def getPaymentHistoryForCustomer(self, customer_id: int) -> List[Payment]:
        cursor = self.connection.cursor()
        query = """
                SELECT p.* 
                FROM Payment p 
                JOIN Lease l ON p.leaseID = l.leaseID 
                WHERE l.customerID = %s
            """
        cursor.execute(query, (customer_id,))
        payment_history = cursor.fetchall()
        cursor.close()
        return payment_history

    def calculateTotalRevenue(self) -> float:
        cursor = self.connection.cursor()
        query = "SELECT SUM(amount) FROM Payment"
        cursor.execute(query)
        total_revenue = cursor.fetchone()[0]
        cursor.close()
        return total_revenue

    def findLeaseById(self, lease_id: int):
        cursor = self.connection.cursor()
        query = "SELECT * FROM Lease WHERE leaseID = %s"
        cursor.execute(query, (lease_id,))
        lease = cursor.fetchone()
        cursor.close()
        if lease:
            return lease
        else:
            raise LeaseNotFoundException(f"Lease with ID {lease_id} not found")
