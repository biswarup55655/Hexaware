from abc import ABC, abstractmethod
from typing import List
from entity import Customer, Lease, Vehicle


class ICarLeaseRepository(ABC):
    @abstractmethod
    def addCar(self, vehicle: Vehicle) -> None:
        pass

    @abstractmethod
    def removeCar(self, vechile_id: int) -> None:
        pass

    @abstractmethod
    def listAvailableCars(self) -> List[Vehicle]:
        pass

    @abstractmethod
    def listRentedCars(self) -> List[Vehicle]:
        pass

    @abstractmethod
    def findCarById(self, vechile_id: int) -> Vehicle:
        pass

    @abstractmethod
    def addCustomer(self, customer: Customer) -> None:
        pass

    @abstractmethod
    def removeCustomer(self, customer_id: int) -> None:
        pass

    @abstractmethod
    def listCustomers(self) -> List[Customer]:
        pass

    @abstractmethod
    def findCustomerById(self, customer_id: int) -> Customer:
        pass

    @abstractmethod
    def createLease(self, lease: Lease):
        pass

    @abstractmethod
    def listActiveLeases(self) -> List[Lease]:
        pass

    @abstractmethod
    def listLeaseHistory(self) -> List[Lease]:
        pass

    @abstractmethod
    def recordPayment(self, lease: Lease, date: str, amount: float) -> None:
        pass
