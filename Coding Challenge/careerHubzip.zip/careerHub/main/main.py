from datetime import datetime
from dao.databaseManger import DatabaseManager
from entity.Applicant import Applicant
from entity.Company import Company
from entity.JobApplication import JobApplication
from entity.JobListing import JobListing
import mysql.connector
from exception.Custom_Exceptions import InvalidEmailFormatError, NegativeSalaryError


class MainClass:
    def __init__(self):
        self.connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='rupen',
            database='careerhub'
        )
        self.db_manager = DatabaseManager(self.connection)

    @staticmethod
    def display_menu():
        print("\nMain Menu")
        print("1. Initialize Database")
        print("2. Insert Job Listing")
        print("3. Insert Company")
        print("4. Insert Applicant")
        print("5. Insert Job Application")
        print("6. Get Job Listings")
        print("7. Get Companies")
        print("8. Get Applicants")
        print("9. Get Applications for Job")
        print("10. Salary Range")
        print("A. Exit")

    def run(self):
        while True:
            self.display_menu()
            choice = input("Enter your choice: ")

            if choice == '1':
                try:
                    self.db_manager.InitializeDatabase()
                    print("Database initialized successfully!")
                except Exception as e:
                    print("Error:", e)

            elif choice == '2':
                try:
                    title = input("Enter Job Title: ")
                    description = input("Enter Job Description: ")
                    location = input("Enter Job Location: ")
                    salary = float(input("Enter Salary: "))
                    job_type = input("Enter Job Type: ")
                    posted_date = datetime.now()
                    job_listing = JobListing(title, description, location, salary, job_type, posted_date)
                    self.db_manager.InsertJobListing(job_listing)
                    print("Job Listing inserted successfully!")
                except Exception as e:
                    print("Error:", e)

            elif choice == '3':
                try:
                    company_name = input("Enter Company Name: ")
                    location = input("Enter Company Location: ")
                    company = Company(company_name, location)
                    self.db_manager.InsertCompany(company)
                    print("Company inserted successfully!")
                except Exception as e:
                    print("Error:", e)

            elif choice == '4':
                try:
                    first_name = input("Enter First Name: ")
                    last_name = input("Enter Last Name: ")
                    email = input("Enter Email: ")
                    phone = input("Enter Phone: ")
                    resume = input("Enter Resume: ")
                    if "@" not in email or "." not in email:
                        raise InvalidEmailFormatError("Invalid email format. Please enter a valid email address.")
                    applicant = Applicant(first_name, last_name, email, phone, resume)
                    self.db_manager.InsertApplicant(applicant)
                    print("Applicant inserted successfully!")
                except Exception as e:
                    print("Error:", e)

            elif choice == '5':
                try:
                    job_id = int(input("Enter Job ID: "))
                    applicant_id = int(input("Enter Applicant ID: "))
                    application_date = datetime.now()
                    cover_letter = input("Enter Cover Letter: ")
                    self.db_manager.InsertJobApplication(JobApplication(job_id, applicant_id, application_date,
                                                                        cover_letter))
                    print("Job Application inserted successfully!")
                except Exception as e:
                    print("Error:", e)

            elif choice == '6':
                try:
                    job_listings = self.db_manager.GetJobListings()
                    print("Job Listings:")
                    for job in job_listings:
                        print(job)
                except Exception as e:
                    print("Error:", e)

            elif choice == '7':
                try:
                    companies = self.db_manager.GetCompanies()
                    print("Companies:")
                    for company in companies:
                        print(company)
                except Exception as e:
                    print("Error:", e)

            elif choice == '8':
                try:
                    applicants = self.db_manager.GetApplicants()
                    print("Applicants:")
                    for applicant in applicants:
                        print(applicant)
                except Exception as e:
                    print("Error:", e)

            elif choice == '9':
                try:
                    job_id = int(input("Enter Job ID: "))
                    applications = self.db_manager.GetApplicationsForJob(job_id)
                    print("Applications for Job ID", job_id, ":")
                    for application in applications:
                        print(application)
                except Exception as e:
                    print("Error:", e)

            elif choice == '10':
                try:
                    min_salary = float(input("Enter minimum salary: "))
                    max_salary = float(input("Enter maximum salary: "))
                    job_listings = self.db_manager.GetJobListingsInSalaryRange(min_salary, max_salary)
                    print("Job Listings within salary range:")
                    for job in job_listings:
                        print(job)
                except NegativeSalaryError as e:
                    print("Error:", e)
                except Exception as e:
                    print("Error:", e)
            elif choice == "A":
                print("Exiting program.")
                break
            else:
                print("Invalid choice. Please enter a valid option.")



if __name__ == '__main__':
    menu = MainClass()
    menu.run()
