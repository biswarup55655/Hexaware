class JobApplication:
    def __init__(self, job_id, applicant_id, application_date, cover_letter):
        self.job_id = job_id
        self.applicant_id = applicant_id
        self.application_date = application_date
        self.cover_letter = cover_letter
