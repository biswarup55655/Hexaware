from entity.JobListing import JobListing
from datetime import datetime


class Company:
    def __init__(self, name, location):
        self.name = name
        self.location = location
        self.jobs = []

    """ def post_job(self, title, description, location, salary, job_type):
        job = JobListing(len(self.jobs) + 1, self.company_id, title, description, location, salary, job_type,
                         datetime.now())
        self.jobs.append(job)"""

    def get_jobs(self):
        return self.jobs
