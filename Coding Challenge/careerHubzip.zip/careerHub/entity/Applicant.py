class Applicant:
    def __init__(self, first_name, last_name, email, phone, resume):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.phone = phone
        self.resume = resume

    def create_profile(self, email, first_name, last_name, phone):
        self.email = email
        self.first_name = first_name
        self.last_name = last_name
        self.phone = phone

    def apply_for_job(self, job_id, cover_letter):
        pass
