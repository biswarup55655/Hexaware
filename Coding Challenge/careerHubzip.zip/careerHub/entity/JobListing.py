from entity.JobApplication import JobApplication
from datetime import datetime


class JobListing:
    def __init__(self, company_id, title, description, location, salary, job_type, posted_date=None):
        self.company_id = company_id
        self.title = title
        self.description = description
        self.location = location
        self.salary = salary
        self.job_type = job_type
        self.posted_date = posted_date or datetime.now()
        self.applicants = []

    """def apply(self, job_id, applicant_id, cover_letter):
        application = JobApplication(len(self.applicants) + 1, job_id, applicant_id, datetime.now(), cover_letter)
        self.applicants.append(application)"""

    def get_applicants(self):
        return self.applicants
