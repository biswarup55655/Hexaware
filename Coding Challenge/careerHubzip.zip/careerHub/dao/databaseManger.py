import mysql.connector

class DatabaseManager:
    def __init__(self, connection):
        try:
            self.connection = connection
            print("Database connection established successfully!")
        except mysql.connector.Error as e:
            print("Error:", e)

    def InitializeDatabase(self):
        curr = self.connection.cursor()
        create_companies_table = """CREATE TABLE IF NOT EXISTS Companies (
               CompanyID INT AUTO_INCREMENT PRIMARY KEY,
               CompanyName VARCHAR(255),
               Location VARCHAR(255));"""
        curr.execute(create_companies_table)
        create_jobs_table = """CREATE TABLE IF NOT EXISTS Jobs (JobID INT AUTO_INCREMENT PRIMARY KEY,
                   CompanyID INT,
                   JobTitle VARCHAR(100),
                   JobDescription TEXT,
                   JobLocation VARCHAR(255),
                   Salary DECIMAL(10, 2),
                   JobType VARCHAR(50),
                   PostedDate DATETIME,
                   FOREIGN KEY (CompanyID) REFERENCES Companies(CompanyID));"""
        create_applicants_table = """CREATE TABLE IF NOT EXISTS Applicants (
                   ApplicantID INT AUTO_INCREMENT PRIMARY KEY,
                   FirstName VARCHAR(100),
                   LastName VARCHAR(100),
                   Email VARCHAR(255),
                   Phone VARCHAR(20),
                   Resume VARCHAR(255));"""
        create_applications_table = """CREATE TABLE IF NOT EXISTS Applications (
                   ApplicationID INT AUTO_INCREMENT PRIMARY KEY,
                   JobID INT,
                   ApplicantID INT,
                   ApplicationDate DATETIME,
                   CoverLetter TEXT,
                   FOREIGN KEY (JobID) REFERENCES Jobs(JobID),
                   FOREIGN KEY (ApplicantID) REFERENCES Applicants(ApplicantID));"""
        curr.execute(create_jobs_table)
        curr.execute(create_companies_table)
        curr.execute(create_applicants_table)
        curr.execute(create_applications_table)
        self.connection.commit()
        curr.close()

    def InsertJobListing(self, job):
        curr = self.connection.cursor()
        query = """INSERT INTO Jobs (JobTitle, JobDescription, JobLocation, Salary, JobType, PostedDate)
                       VALUES (%s, %s, %s, %s, %s, %s, %s)"""
        data = (job.title, job.description, job.location, job.salary, job.job_type, job.posted_date)
        curr.execute(query, data)
        self.connection.commit()
        curr.close()

    def InsertCompany(self, company):
        curr = self.connection.cursor()
        query = """INSERT INTO Companies (CompanyName, Location)VALUES (%s, %s)"""
        data = (company.name, company.location)
        curr.execute(query, data)
        self.connection.commit()
        curr.close()

    def InsertApplicant(self, applicant):
        curr = self.connection.cursor()
        query = "INSERT INTO Applicant(FirstName, LastName, Email, Phone, Resume) VALUES(%s,%s,%s,%s,%s)"
        data = (applicant.first_name, applicant.last_name, applicant.email, applicant.phone, applicant.resume)
        curr.execute(query, data)
        self.connection.commit()
        curr.close()

    def InsertJobApplication(self, application):
        curr = self.connection.cursor()
        query = "INSERT INTO JobApplication(JobID, ApplicantID, ApplicationDate, CoverLetter) VALUES(%s,%s,%s,%s)"
        data = (application.job_id, application.applicant_id, application.application_date, application.cover_letter)
        curr.execute(query, data)
        self.connection.commit()
        curr.close()

    def GetJobListings(self):
        curr = self.connection.cursor()
        query = "SELECT * FROM JobListing"
        curr.execute(query)
        joblist = curr.fetchall()
        self.connection.commit()
        curr.close()
        return joblist

    def GetCompanies(self):
        curr = self.connection.cursor()
        select_companies_query = """SELECT * FROM Companies"""
        curr.execute(select_companies_query)
        companies = curr.fetchall()
        curr.close()
        return companies

    def GetApplicants(self):
        curr = self.connection.cursor()
        query = """SELECT * FROM Applicants"""
        curr.execute(query)
        applicants = curr.fetchall()
        curr.close()
        return applicants

    def GetApplicationsForJob(self, job_id):
        curr = self.connection.cursor()
        select_applications_query = """SELECT * FROM Applications WHERE JobID = %s"""
        curr.execute(select_applications_query, (job_id,))
        applications = curr.fetchall()
        curr.close()
        return applications

    def GetJobListingsInSalaryRange(self, min_salary, max_salary):
        curr = self.connection.cursor()
        query = "SELECT * FROM Jobs WHERE Salary BETWEEN %s AND %s"
        data = (min_salary, max_salary)
        curr.execute(query, data)
        job_listings = curr.fetchall()
        curr.close()
        return job_listings
