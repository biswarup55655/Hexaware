class InvalidEmailFormatError(Exception):
    pass


def register_applicant(email):
    if "@" not in email or "." not in email:
        raise InvalidEmailFormatError("Invalid email format. Please enter a valid email address.")

    try:
        email = input("Enter your email address: ")
        register_applicant(email)
        print("Registration successful!")
    except InvalidEmailFormatError as e:
        print("Error:", e)


class NegativeSalaryError(Exception):
    pass
